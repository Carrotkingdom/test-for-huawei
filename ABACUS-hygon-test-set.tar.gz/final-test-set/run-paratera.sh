OMP_NUM_THREADS=1 mpirun -np 32 abacus | tee out.log
